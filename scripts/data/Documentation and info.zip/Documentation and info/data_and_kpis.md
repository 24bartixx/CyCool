# Data and KPIs

## 1. Data listed in the challenge sheet (VAS-R1)
| Data | Source | Use |
|---|---|---|
| **Cycling segments with shade, heat and riders** | Synthetic VAS-R1 dataset | Core: Heat Exposure Index, heat map, priority score |
| **Junctions and stations** | Synthetic VAS-R1 dataset | Junction exposure (waiting in full sun), map markers |
| **Catalogue of solutions with costs** | Synthetic VAS-R1 dataset | Optimiser input; cost and °C KPIs |
| Cycle lanes and cycle streets | Viladecans 360 | Real network geometry |
| Street map (Carrerer) | Viladecans 360 | Base map, street names, shaded missing links |
| Bicibox AMB stations, AMBici stations | Viladecans 360 | Station layer |
| Mobility portal | Viladecans al dia | Context |
| Trees, shade, heat islands | Bessó Digital (digital twin) portal | Validate synthetic heat/shade; shade layer |
| Solar radiation | Bessó Digital | Sun exposure |
| Drinking fountains, facilities | Viladecans 360 | Water/rest points |
| Climate shelters | Bessó Digital | Refuge points along routes |

**Only the VAS-R1 dataset is synthetic.** Label it as demo data in the UI.

Portal: https://360.viladecans.cat/ (downloads in CSV, KML, Zip, GeoJSON, GeoTIFF, PNG; APIs via GeoServices, WMS, WFS).

## 2. Data outside the challenge sheet (optional)
| Data | Source | Use |
|---|---|---|
| Population by age and census section | Viladecans 360 (exact link not found; ask organisers) | Social KPI, prioritising vulnerable areas, hidden demand |
| Census section boundaries (urban) | https://360.viladecans.cat/datasets/4e932e3ed4744762aaa885f8ea2a9624_7/about | Polygons to join population onto |
| Population by neighbourhood and sex (dashboard) | https://360.viladecans.cat/content/de8845787fd4492ea7e46db696f065b0 | Fallback population data (no age split) |
| Real temperatures | Meteocat XEMA, Viladecans station | Realistic time-of-day heat |
| Base map / road graph | OpenStreetMap | Backup routing network |

Population data is **optional**: rider counts are enough for the MVP.

## 3. Actual dataset schema
> TODO: fill in after downloading the VAS-R1 CSVs (file names, columns, units, keys).

## 4. Assumptions (must be sourced and cited)
Keep these in one config file (e.g. `assumptions.yaml`) so KPIs recalculate when they change.
| Assumption | Used for | Source |
|---|---|---|
| Car emission factor (kgCO₂e/km) | tCO₂e avoided | MITECO or OCCC (Catalan Office for Climate Change). TODO |
| Car cost per km (€/km) | € saved per user | TODO: official source |
| Share of new bike trips replacing car trips | CO₂, € saved | TODO: study or city mobility data; be conservative |
| Drop in ridership on red segments in heat | New summer cyclists | From rider data if possible, else stated assumption |
| Lifespan of each fix type | Annualised costs | Catalogue or supplier data. TODO |
| Comfort threshold on the index | Comfortable km | Our choice, state it (e.g. index < 0.4) |
| Summer days counted | Annual figures | e.g. June–September; state it |

## 5. KPI formulas
All computed as **before vs after** the selected plan.

### Climate
1. **km of climate-comfortable routes** = Σ length of segments with index below the comfort threshold. Report the gain and the % of the network.
2. **°C reduction at critical points** = for hotspots receiving a fix, segment temperature − catalogue cooling value. Report the average and the max.
3. **tCO₂e avoided** = new summer cyclists × trips/day × avg trip km × summer days × share replacing car trips × car emission factor.

### Economic
4. **€ per km adapted** = total plan cost ÷ km that became comfortable.
5. **€ per new summer cyclist** = total plan cost ÷ new summer cyclists. Also show annualised by fix lifespan.
6. **€ saved per user per year** = car trips replaced × km × car cost per km.

### Common KPIs
- **Health:** heat-exposure minutes avoided = Σ riders × minutes on red segments (before − after); active minutes added = new cyclists × trip duration.
- **Environmental:** m² of new shade, trees planted, m² of cool/permeable paving, litres of water provided.
- **Economic (% spending kept locally):** share of plan budget going to local suppliers/installers (estimate).
- **People:** jobs from installation and maintenance (rough FTE estimate).
- **Social:** residents within ~300 m of improved segments, by age group (needs population data).

### Biggest lever
Choosing the right segments: the optimiser targets busy, hot, cheap-to-fix places first, so most KPIs improve together.
