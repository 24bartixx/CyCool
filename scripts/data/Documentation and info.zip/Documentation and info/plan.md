# Build plan (48 hours)

All times are Europe/Warsaw. Check the latest instructions from the organisers on Discord. Documents conflict in places (e.g. video length 30 s vs 1 min); the terms of participation say a **1-minute** solution video.

## Event schedule (from the programme)
**Day 1, Thu 19 Nov**
- 09:30 Registration · 10:00 Opening (themes, rules, judging criteria)
- 10:30 1-minute individual idea pitches
- 11:30 Team formation (teams must be formally registered by the end of this slot)
- 12:30 Workshop 1: problem identification and design thinking
- 14:30–19:30 Hacking with mentoring; teams may continue remotely afterwards

**Day 2, Fri 20 Nov**
- 09:00 Check-in · 09:30 Workshop 2: prototyping, validation, pitch deck
- 10:30–16:30 Teamwork and mentoring
- **16:30–16:45 Final submission deadline**
- 16:45 Final presentations · 18:00 Jury · 19:00 Winners

## Deliverables
1. **1-minute solution video** (semi-final gate, our most important deliverable)
2. **Pitch deck** (3 min + 2 min Q&A; 4 + 2 if also going for the pilot award)
3. **Working demo** of the web dashboard
4. Google Form with team details, authorship declaration, rules acceptance
5. Optional: code repository link, supporting documents
6. If going for the Climate Mission Award: **1-minute pilot video** + written 12-month pilot summary

## Team split (3 people)
| Role | Owns |
|---|---|
| **Data/AI** | Load and clean the VAS-R1 CSVs, Heat Exposure Index, priority score, optimiser, KPI calculator, assumptions config |
| **Backend + frontend** | FastAPI endpoints, React dashboard, Leaflet map, hotspot list, optimiser UI, before/after toggle, KPI panel |
| **Product + pitch** | Real open-data layers, deck, 1-minute video, pilot plan, work log, assumptions/sources list; helps with the frontend |

If a 4th/5th member joins with domain knowledge, they own the fix catalogue review, the health story and the pilot plan.

## Timeline
**Thursday afternoon**
- [ ] Download the VAS-R1 dataset; document the actual schema in `data_and_kpis.md`
- [ ] Ask mentor/Discord: are new cycle connections allowed, or only improvements to existing segments?
- [ ] Draft Heat Exposure Index; first static heat map of the network
- [ ] FastAPI skeleton + React app with the map rendering segments

**Thursday evening (remote)**
- [ ] Hotspot ranking and segment detail panel
- [ ] First version of the optimiser (greedy cost-effectiveness is fine)
- [ ] Assumptions config with sources

**Friday morning**
- [ ] Optimiser UI (budget + goal → plan table)
- [ ] Before/after toggle; KPI panel with live numbers
- [ ] Stretch only if MVP works: real data layers, time-of-day slider

**Friday 13:00–14:00: feature freeze**

**Friday 14:00–16:30**
- [ ] Record the 1-minute video (screen recording of the demo flow + voiceover)
- [ ] Finish the deck; rehearse the 3-minute pitch and likely Q&A
- [ ] Pilot video and summary (if applying)
- [ ] Submit before 16:30

## Demo script (also the video storyboard)
1. **Problem (10 s):** "In July, X% of Viladecans' cycle network is uncomfortable to ride." Show the red heat map at 15:00.
2. **Insight (10 s):** hotspot ranking: busy and hot segments first.
3. **Solution (25 s):** set budget €50k → Generate plan → plan table → flip to "after" → map turns green.
4. **Impact (10 s):** KPI headline, e.g. "+9 km comfortable · −3 °C at hotspots · €38 per new summer cyclist".
5. **Close (5 s):** next step: pilot in Viladecans next summer; cyclist app in phase 2.

## Pitch structure (3 minutes)
1. Problem and who suffers (heat, health, lost cyclists)
2. Our solution and live demo
3. KPIs with assumptions stated
4. Business model (licences for councils and bike-share operators, sponsored shade)
5. Pilot in Viladecans (if applying) and team

## Q&A prep
- How did you validate the synthetic data? (Plan to use Bessó Digital heat data and sensors in the pilot.)
- Where do the CO₂ and € figures come from? (Assumptions list with sources.)
- Why would cyclists come back? (Rider data / stated assumption; pilot measures it.)
- Cost and maintenance of fixes? (Catalogue costs, lifespans, local maintenance.)
- Why is this better than a route app? (It changes the infrastructure; the app is phase 2.)
