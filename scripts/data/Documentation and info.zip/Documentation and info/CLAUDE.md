# CLAUDE.md

Context for Claude Code. Read this first, then the linked docs.

## What this repo is
A 48-hour hackathon project for the **Mission Climate Hackathon · Tri-City Hackathon Unite! Widening 2026** (19–20 Nov 2026, Viladecans · Lisbon · Wrocław). We are solving challenge **VAS-R1 "Comfortable cycling routes"** from Viladecans City Council (Spain).

We are building a **web dashboard for city planners** that:
1. scores every cycling segment for heat exposure,
2. ranks the worst hotspots,
3. picks the best set of heat-mitigation fixes for a given budget (the core feature),
4. shows the before/after effect and calculates the challenge KPIs.

A cyclist-facing mobile app is **out of scope for now**.

## Docs
- `project_description.md`: challenge, goal, scope, features, KPIs, pilot plan
- `plan.md`: 48h build plan, team split, deliverables, demo script, deadlines
- `data_and_kpis.md`: data sources, expected dataset contents, assumptions, KPI formulas

## Team
3 final-year Applied Computer Science students (WroclawTech / WUST), competing in the Wrocław group. Strong in Python, FastAPI, React, AI/ML, data, AWS. We are looking for 1–2 more members with domain knowledge (urban planning, health, landscaping, business).

## Tech stack (default choices, change if there is a good reason)
- **Data and analysis:** Python, pandas, geopandas, networkx
- **Optimiser:** knapsack-style selection (PuLP/OR-Tools or a greedy cost-effectiveness heuristic as a fallback)
- **Backend:** FastAPI (REST API serving segments, hotspots, optimiser results, KPIs)
- **Frontend:** React + Leaflet (or react-leaflet) map, simple component library
- **Storage:** CSV/GeoJSON files loaded in memory are fine for the demo; a database is optional

## Ground rules
- **Speed over polish.** Final submission is Friday 20 Nov around 16:30 (Warsaw time). A working demo beats unfinished features.
- **The VAS-R1 dataset is synthetic.** Never present it as real Viladecans data. Label it "synthetic/demo data" in the UI and docs.
- **Every assumption must be explicit and sourced** (emission factors, car cost per km, modal shift share). Keep them in one config file and list them in `data_and_kpis.md`.
- **All KPI numbers must come from code**, recalculated live from the current plan, not hard-coded.
- **Credit generative AI tools and open-source licences** (hackathon rule). Keep a short note of where AI was used.
- **Prior work must be disclosed.** Anything built before the hackathon must be identified as such.
- **Keep a work log** of who did what. The rules require each member's contribution to be documented.
- Real dataset column names are not known yet. Inspect the CSVs before writing code against them and update `data_and_kpis.md` with the actual schema.
