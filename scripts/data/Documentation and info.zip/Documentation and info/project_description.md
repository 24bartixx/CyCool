# Project description: heat-aware cycling network planner

Working name: TBD (shortlist: "Ombra", "404: Shade Not Found", "The Shady Business").

## 1. The hackathon
- **Event:** Mission Climate Hackathon · Tri-City Hackathon Unite! Widening 2026, 19–20 November 2026. Hybrid: Viladecans (Can Calderón), Lisbon, Wrocław and online.
- **Organisers:** Viladecans City Council with Unite! (ULisboa, UPC BarcelonaTech, WroclawTech).
- **Language:** English.
- **Team rules:** 4–5 members as standard; smaller teams need organiser approval. One contact person (team lead). Every member's contribution must be documented.

### Competition format
1. **Semi-final (pre-selection):** one Google Form per team plus a **1-minute solution video**. Teams applying for the Climate Mission Award also submit a **1-minute pilot video** and a written summary of a 12-month pilot plan.
2. **Final:** 12 teams for the overall prize (3 Viladecans/Catalonia, **3 Wrocław**, 3 Lisbon, 3 online-only), plus up to 4 extra teams for the pilot award. Live pitch: **3 min + 2 min Q&A**, or **4 min + 2 min** when competing for both awards (the extra minute is only for the pilot).

### Scoring: Hackathon Award (each criterion 0–10, weighted to 100)
| Criterion | Weight | What it means for us |
|---|---|---|
| Climate, economic, health/biotech and city impact | 30% | Measurable KPIs, strong health story (heat exposure) |
| Innovation and quality of the solution | 25% | The budget optimiser and Heat Exposure Index are our differentiators |
| Technical and economic viability | 25% | Working demo, cost figures, risks |
| Evidence and quality of presentation | 20% | Justified data use, clear video and pitch, good Q&A answers |

**Prize:** a tech kit worth €600 per member (up to 5) plus a trip to a Unite! event.

### Climate Mission Award (optional, scored separately 0–10)
Rewards the strongest 12-month pilot plan in Viladecans plus the team's commitment to run it. Assessed on plan coherence, feasibility (resources, partners, permits), planning and schedule, impact and monitoring indicators, and team commitment. **Prize:** €7,000 in acceleration and mentoring.

## 2. The challenge: VAS-R1 "Comfortable cycling routes"
**Proposer:** Viladecans City Council. **Vertical:** Active and healthy living.

**Question:** How do we adapt the city's cycling routes and infrastructure to summer heat?

Viladecans has been expanding its cycle network, but in summer cycling is uncomfortable: sections with no shade, waits at traffic lights in full sun, few water or rest points, and big temperature differences between routes. The challenge is to identify the sections most exposed to heat and propose solutions so people keep cycling safely and comfortably in the hottest months. Tech teams are encouraged to combine shade, temperature and rider data to find vulnerable sections and recommend routes based on climate comfort.

**Suggested customers:** city councils, bike-sharing operators, companies with mobility plans, users.
**Suggested revenue:** licences for councils and operators, sale or rental of street furniture, advertising or sponsorship.

## 3. Our goal
Give the city a data-driven tool that answers: **"Where should we spend our budget to make the most cycling kilometres comfortable in summer, and what will it achieve?"**

Most teams will build only a "cool route" app. Our edge is the **budget optimiser** that uses the challenge's catalogue of fixes with costs to recommend where to invest, and proves the impact with live KPIs.

## 4. Scope
### In scope (web dashboard for city planners)
**MVP (must work in the Friday demo)**
1. **Network heat map:** cycle segments coloured green/yellow/red by Heat Exposure Index; line thickness = rider count; junctions shown as circles (red if waiting is in full sun).
2. **Hotspot ranking:** top 10 worst segments and junctions by priority score (heat × riders), with °C, shade %, riders/day and a suggested fix. Clicking a row zooms the map.
3. **Segment detail panel:** why a segment is red (e.g. "320 m with no shade, 90 s wait in full sun, no fountain nearby").
4. **Budget optimiser:** budget input plus a goal (maximise comfortable km, °C reduction, or cyclists protected), producing the best set of fixes from the catalogue.
5. **Before/after view:** map redraws with the plan applied; KPI bar updates.
6. **KPI panel:** all challenge KPIs computed live from the current plan.

**Stretch**
- Time-of-day slider (heat changes from 8:00 to 20:00)
- Scenario comparison (plan A vs plan B)
- Exportable report for the council (PDF, optionally LLM-written summary)
- Real open-data layers (fountains, climate shelters, bike stations, trees/shade) on top of synthetic data
- "Shaded missing links": short connections through already-shaded streets that bypass red hotspots
- Simple route comparison in the dashboard (fastest vs coolest route between two points)

### Out of scope (for now)
- Cyclist mobile app (cool-route navigation, heat alerts, rider feedback). Mention it as the next phase in the pitch.
- Designing new cycle lanes from scratch. **Open question:** check whether the solutions catalogue includes new lanes, and ask a mentor whether new connections are allowed.

## 5. Core logic
### Heat Exposure Index (per segment, 0–1)
Combines: temperature/heat, lack of shade, sun exposure at junctions (waiting time in full sun), and distance to water/rest points. A **priority score** = Heat Exposure Index × riders, so busy hot segments rank first.
Exact formula to be fixed once the dataset columns are known (see `data_and_kpis.md`).

### Budget optimiser
Knapsack-style selection: choose fixes from the catalogue (trees, shade sails, canopies at junctions, fountains, rest points, cool/permeable paving…) to maximise the chosen goal within the budget. Each fix changes segment attributes (shade ↑, temperature ↓), which recomputes the index and the KPIs.

## 6. KPIs we must report
| Type | KPI |
|---|---|
| Climate | km of climate-comfortable routes; °C reduction at critical points; tCO₂e avoided through replaced trips |
| Economic | € per km of adapted route; € per new summer cyclist; € saved per user per year |
| Common (all challenges) | Health (healthier city), Environmental (kg, m³, m² saved or regenerated), Economic (% of spending kept locally), People (local, inclusive jobs), Social (people and groups that benefit) |

Formulas, levers and assumptions: `data_and_kpis.md`.

### How the solution improves the KPIs (story for the pitch)
- **Comfortable km:** cheap shade on long unshaded stretches; use existing shaded parallel streets.
- **°C at critical points:** canopies over traffic-light waiting areas, light-coloured or permeable paving, misting points/fountains, shorter bike waits during heat alerts.
- **CO₂:** bring summer cyclists back on busy commuter routes; trees also store carbon.
- **Cost KPIs:** the optimiser spends where each euro buys the most comfort; reusable temporary fixes first; sponsorship co-funding.
- **Health:** fewer heat-exposure minutes, more active minutes, priority for areas with vulnerable people (older people, children).
- **Local economy and jobs:** local suppliers and installers; maintenance by city gardeners and social-employment companies.

## 7. Pilot plan sketch (for the Climate Mission Award)
1. **Months 1–2:** validate the index against real Bessó Digital heat data; install a few low-cost temperature sensors at the 5 worst junctions.
2. **Months 3–5:** run the dashboard with the city's mobility and urban planning departments; agree the first plan.
3. **Months 6–9 (summer):** install temporary shade and water at top-ranked junctions; measure °C, rider counts and feedback.
4. **Months 10–12:** report KPIs; plan permanent fixes; license to other AMB municipalities or bike-share operators.

**Partners:** Viladecans mobility and urban planning departments, AMB bike-share operators (AMBici, Bicibox), a street-furniture supplier, local installers.
**Needs:** data access, permits for temporary installations, a small hardware budget, team availability.

## 8. Team and recruiting
- 3 CS students: full-stack, AI/ML, data, cloud.
- Looking for 1–2 people with domain knowledge in any challenge area or a non-technical background (urban planning, landscaping, health, business, design).
